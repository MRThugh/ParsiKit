"""ParsiKit automated test suite."""
